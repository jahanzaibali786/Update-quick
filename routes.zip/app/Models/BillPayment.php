<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BillPayment extends Model
{
    protected $fillable = [
        'bill_id',
        'date',
        'account_id',
        'payment_method',
        'reference',
        'description',
        'voucher_id',
        'amount',
        'payment_type',
        'coa_account',
    ];


    public function bankAccount()
    {
        return $this->hasOne('App\Models\BankAccount', 'id', 'account_id');
    }
    
    public function bill()
    {
        return $this->belongsTo('App\Models\Bill', 'bill_id');
    }
    
}
